package uy.edu.ucu.aed2;

import java.util.LinkedList;

public class Main {

    /**
     * @param args
     */
    public static void main(String[] args){
        TArbolTrie trie = new TArbolTrie();

        String[] palabrasclave = ManejadorArchivosGenerico.leerArchivo("./src/main/java/uy/edu/ucu/aed2/palabrasPrueba.txt");
        for (String p : palabrasclave) {
                trie.insertar(p);
        }
        trie.imprimir();


        String aBuscar1 = "metropolitano";
        String aBuscar2 = "arboleada";
        String aBuscar3 = "mam";

        int comparaciones = trie.buscar(aBuscar1);
        System.out.printf("La busqueda de: '%s' realizó: [%d] comparaciones \n",aBuscar1,comparaciones);
        
        comparaciones = trie.buscar(aBuscar2);
        System.out.printf("La busqueda de: '%s' realizó: [%d] comparaciones \n",aBuscar2,comparaciones);
        
        comparaciones = trie.buscar(aBuscar3);
        System.out.printf("La busqueda de: '%s' realizó: [%d] comparaciones \n",aBuscar3,comparaciones);


        // <-- Prueba de predicción -->
        System.out.println("\nPredicción de 'mu':");
        LinkedList<String> predict = trie.predecir("mu");
        System.out.println(predict.toString());
    }
}