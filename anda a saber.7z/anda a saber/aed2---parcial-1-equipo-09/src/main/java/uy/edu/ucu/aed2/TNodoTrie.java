package uy.edu.ucu.aed2;

import java.util.Arrays;
import java.util.LinkedList;

public class TNodoTrie implements INodoTrie {

    private static final int CANT_CHR_ABECEDARIO = 2;
    private TNodoTrie[] hijos;
    private boolean esPalabra;
    private int[] posArray;

    public TNodoTrie() {
        hijos = new TNodoTrie[CANT_CHR_ABECEDARIO];
        esPalabra = false;
        posArray = new int[2];
    }

    @Override
    public void insertar(String unaPalabra, int[] posEnArray) {
        TNodoTrie nodo = this;
        for (int c = 0; c < unaPalabra.length(); c++) {
            int indice = unaPalabra.charAt(c) - '0'; //Character.getNumericValue(unaPalabra.charAt(c));
            if (nodo.hijos[indice] == null) {
                nodo.hijos[indice] = new TNodoTrie();
            }
            nodo = nodo.hijos[indice];
        }
        nodo.esPalabra = true;
        nodo.posArray = posEnArray;
    }

    private TNodoTrie buscarNodoTrie(String unaPalabra) {
        TNodoTrie nodo = this;
        for (int c = 0; c < unaPalabra.length(); c++) {
            int indice = unaPalabra.charAt(c) - '0'; //Character.getNumericValue(unaPalabra.charAt(c));
            if (nodo.hijos[indice] == null) {
                return null;
            } else {
                nodo = nodo.hijos[indice];
            }
        }
        return nodo;
    }

    private void predecir(String s, String sufijo, LinkedList<Integer> ocurrencias, TNodoTrie nodo) {
        
        
        if(nodo != null){
            for(int c = 0; c < CANT_CHR_ABECEDARIO; c++){
                    if(nodo.hijos[c] !=  null){
                        predecir("" + (char) (c + 'a'), sufijo, ocurrencias, nodo.hijos[c]);
                    }
                }
            if(nodo.esPalabra == true){
                ocurrencias.add(nodo.posArray[0]);
            }
      
                
            
        }
    }

    @Override
    public void predecir(String sufijo, LinkedList<Integer> ocurrencias) {
        TNodoTrie buscado = buscarNodoTrie(sufijo);
        this.predecir("", sufijo, ocurrencias, buscado);
    }

    @Override
    public int buscar(String unaPalabra) {
        TNodoTrie nodoAux = this;
        int comparaciones = 0;
        for (int c = 0; c < unaPalabra.length(); c++) {
            comparaciones++;
            int indice = unaPalabra.charAt(c) - 'a';
            if (nodoAux.hijos[indice] == null) {
                return -comparaciones;
            } else {
                nodoAux = nodoAux.hijos[indice];
            }
        }
        if (nodoAux.esPalabra) {
            return comparaciones;
        }
        return -comparaciones;
    }

}