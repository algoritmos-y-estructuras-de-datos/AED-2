package uy.edu.ucu.aed2;

import java.util.Arrays;
import java.util.LinkedList;

public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // INSTANCIAR UN TRIE
        
        TArbolTrie arbol = new TArbolTrie();

        // LEER LA CADENA DE AMINOACIDOS DESDE EL ARCHIVO
        String[] secuencia = ManejadorArchivosGenerico.leerArchivo("C:/Source/aed2---parcial-1-equipo-09/src/main/java/uy/edu/ucu/aed2/mensaje.txt");
        // GENERAR TODOS LOS SUFIJOS E INSERTARLOS EN EL TRIE, CUIDANDO DE REGISTRAR LA POSICIÓN 
        char[] datos = new char[secuencia[0].length()];

        for(int i = 0; i < secuencia[0].length(); i++){
            datos[i] = secuencia[0].charAt(i);
        }

        for(int x = 0; x < datos.length; x++){
            char[] sliceAux = Arrays.copyOfRange(datos, x, datos.length);
            String proxSufijo = ""; 
            
            for(int i = 0; i< sliceAux.length; i++){
                proxSufijo += sliceAux[i];
            }
            int[] posEnArray = new int[2];
            posEnArray[0] = x;
            posEnArray[1] = datos.length;

            arbol.insertar(proxSufijo, posEnArray);
        }

        String patron1 = "110101";
        String patron2 = "1101011";
        
        LinkedList<Integer> listAuxParte1 = arbol.encontrarPatron(patron1);
        String[] aEscribir1 = new String[listAuxParte1.size()];
        for(int i = 0; i < listAuxParte1.size(); i++){
            aEscribir1[i] =  "Patron: " + patron1 + " encontrado en pos: " + Integer.toString(listAuxParte1.get(i));
        }
        ManejadorArchivosGenerico.escribirArchivo("salida.txt", aEscribir1);
        
        LinkedList<Integer> listAuxParte2 = arbol.encontrarPatron("1101011");
        String[] aEscribir2 = new String[listAuxParte2.size()];
        for(int i = 0; i < listAuxParte2.size(); i++){
            aEscribir2[i] =  "Patron: " + patron2 + " encontrado en pos: " + Integer.toString(listAuxParte2.get(i));
        }
        ManejadorArchivosGenerico.escribirArchivo("salida.txt", aEscribir2);
        

        

    }
}
