package uy.edu.ucu.aed2;

import java.util.LinkedList;

public interface INodoTrie {

    int buscar(String s);

    void insertar(String unaPalabra, int[] posEnArray);

    public void predecir(String prefijo, LinkedList<Integer> palabras);
    
    
}

