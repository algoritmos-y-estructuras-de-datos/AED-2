package uy.edu.ucu.aed2;

import static org.junit.Assert.*;
import org.junit.*;

import jdk.jfr.Timestamp;

import java.util.*;

public class TestCases {

    TArbolTrie arbolTest = new TArbolTrie();
    @Before
    public void setUp(){
        int[] prueba = {2};

        String secuencia[] = {"1101010010"};
        char[] datos = new char[secuencia[0].length()];


        for(int i = 0; i < secuencia[0].length(); i++){
            datos[i] = secuencia[0].charAt(i);
        }

        for(int x = 0; x < datos.length; x++){
            char[] sliceAux = Arrays.copyOfRange(datos, x, datos.length);
            String proxSufijo = ""; 
            
            for(int i = 0; i< sliceAux.length; i++){
                proxSufijo += sliceAux[i];
            }
            int[] posEnArray = new int[2];
            posEnArray[0] = x;
            posEnArray[1] = datos.length;

            arbolTest.insertar(proxSufijo, posEnArray);
        }
    }
    
    @Test
    public void testEncontrarSufijo() {
        LinkedList<Integer> listaAux = arbolTest.encontrarPatron("10");
        Assert.assertEquals(4, listaAux.size());
    }

    @Test
    public void testNoEncuentraSufijo() {
        LinkedList<Integer> listaAux = arbolTest.encontrarPatron("111");
        Assert.assertEquals(0, listaAux.size());
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testExcepcion() {
        
    }
}
