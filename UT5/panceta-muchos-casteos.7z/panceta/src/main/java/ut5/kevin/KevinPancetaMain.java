package ut5.kevin;

public class KevinPancetaMain {
    
    public static void main(String[] args) {
        
        TGrafoKevinBacon grafoKevinBacon = (TGrafoKevinBacon) UtilGrafos.cargarGrafoKevinBacon("UT5/panceta/src/main/java/ut5/kevin/actores.csv", "UT5/panceta/src/main/java/ut5/kevin/en_pelicula.csv",
                false, TGrafoKevinBacon.class);


        
        System.out.println(grafoKevinBacon.numBacon("Harrison_Ford")); 
        System.out.println(grafoKevinBacon.numBacon("Cate_Blanchett")); 
        System.out.println(grafoKevinBacon.numBacon("Tom_Hanks")); 

        



    }
}
