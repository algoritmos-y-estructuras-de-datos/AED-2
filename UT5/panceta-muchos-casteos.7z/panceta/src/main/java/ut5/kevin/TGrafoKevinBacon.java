package ut5.kevin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class TGrafoKevinBacon extends TGrafoNoDirigido implements IGrafoKevinBacon {
  
    public TGrafoKevinBacon(Collection<TVertice> vertices, Collection<TArista> aristas) {
        super(vertices, aristas);
        lasAristas.insertarAmbosSentidos(aristas);

    }

    @Override
    public boolean insertarVertice(Comparable unaEtiqueta) {
        if ((unaEtiqueta != null) && (!existeVertice(unaEtiqueta))) {
            TVerticeKevinBacon vert = new TVerticeKevinBacon(unaEtiqueta);
            getVertices().put(unaEtiqueta, vert);
            return getVertices().containsKey(unaEtiqueta);
        }
        return false;
    }

    @Override
    public boolean insertarArista(TArista arista) {
        if ((arista.getEtiquetaOrigen() != null) && (arista.getEtiquetaDestino() != null)) {
            TVerticeKevinBacon vertOrigen = (TVerticeKevinBacon) buscarVertice(arista.getEtiquetaOrigen());
            TVerticeKevinBacon vertDestino = (TVerticeKevinBacon) buscarVertice(arista.getEtiquetaDestino());
            if ((vertOrigen != null) && (vertDestino != null)) {
                return vertOrigen.insertarAdyacencia(arista.getCosto(), vertDestino);
            }
        }
        return false;
    }


    @Override
    public int numBacon(Comparable actor) {
        TVerticeKevinBacon kevin = (TVerticeKevinBacon) getVertices().get("Kevin_Bacon");
        kevin.beatrizBacon(actor);
        TVerticeKevinBacon objetivo = (TVerticeKevinBacon) getVertices().get(actor);
        return objetivo.getBacon();
    }


    public int numBacon1(Comparable actor) {
        desvisitarVertices();
        Collection<TVerticeKevinBacon> lista = new LinkedList<>();
        TVerticeKevinBacon vertice = (TVerticeKevinBacon) getVertices().get(actor);
        int numeroBeacon = 0;
        if (vertice != null) {
            numeroBeacon = vertice.numBacon1(lista);
        }
        return numeroBeacon;
    }



}
